package com.example.boot_exam;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.entity.Item;
import com.example.entity.Member;

public class ItemRestControllerTest {

    RestTemplate restTemplate;

    @BeforeEach
    public void setup() {
        restTemplate = new RestTemplate();
    }

    @Test
    public void insertItem() {
        Item item = new Item();
        item.setName("물품1");
        item.setPrice(1234L);
        item.setQuantity(200L);
        item.setContent("물품내용1");

        Member member = new Member();
        member.setUserid("a");
        item.setMember(member);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Item> entity = new HttpEntity<>(item, headers);

        String url = "http://127.0.0.1:9090/ROOT/item/insert.rest";
        ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        System.out.println(result.getBody());

        assertThat(result.getBody().toString()).isEqualTo("{\"status\":200}");
    }

    @Test
    public void deleteItem() {
        Item item = new Item();
        item.setNo(2L);
        // jwt security config filter //
        String url = "http://127.0.0.1:9090/ROOT/item/delete.rest?no=" + item.getNo();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Item> entity = new HttpEntity<>(item, headers);

        ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
        System.out.println(result.getBody());

        assertThat(result.getBody().toString()).isEqualTo("{\"status\":200}");

    }

    @Test
    public void updateItem() {
        Item item = new Item();
        item.setNo(2L);
        item.setName("변경물품1");
        item.setPrice(2345L);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Item> entity = new HttpEntity<>(item, headers);

        String url = "http://127.0.0.1:9090/ROOT/item/update.rest";
        ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.PUT, entity, String.class);
        System.out.println(result.getBody());

        assertThat(result.getBody().toString()).isEqualTo("{\"status\":200}");

    }

    @Test
    public void selectItem() {

    }
}
